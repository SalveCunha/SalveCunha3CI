package com.example.projetosalvecunha;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    EditText textoUser3;
    EditText textoUser2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        getSupportActionBar().hide();
        setContentView( R.layout.tela_login );



        ImageView btnentrar = findViewById(R.id.btnentrar);

        btnentrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference myRef = database.getReference("users");
                int i;
                for(i=1;i<=3;i++){
                    String us = String.valueOf(i);
                    myRef.child(us).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            EditText textoUser3 = findViewById(R.id.textoUser3);
                            EditText textoUser2 = findViewById(R.id.textoUser2);
                            User user = dataSnapshot.getValue(User.class);
                            if(user.getEmail().equals(textoUser3.getText().toString())){
                                if(user.getSenha().equals(textoUser2.getText().toString())){
                                    Intent it = new Intent(getApplicationContext(), TelaInicial.class);
                                    startActivity(it);
                                }
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError error) {

                        }
                    });
                }
                Toast.makeText(getApplicationContext(),"E-mail/Senha incorreto(a)",Toast.LENGTH_LONG).show();
            }

        });



    }

    public void irtelacadastro(View view){
        Intent it = new Intent(getApplicationContext(), TelaCadastro.class);
        startActivity(it);
    }

    public void irtelarecu(View view){
        Intent it = new Intent(getApplicationContext(), RecuperacaoSenha.class);
        startActivity(it);
    }
}